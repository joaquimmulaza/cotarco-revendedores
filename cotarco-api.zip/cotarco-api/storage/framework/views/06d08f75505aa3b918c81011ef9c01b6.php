<?php echo e($slot); ?>

<?php /**PATH C:\cotarco-revendedores\cotarco-api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>