<x-mail::message>
# Conta Temporariamente Desativada

Olá, **{{ $user->name }}**.

Informamos que a sua conta na Rede de Parceiros da Cotarco foi temporariamente desativada.
Durante este período, o acesso ao seu painel estará suspenso.
Caso tenha alguma dúvida ou necessite de esclarecimentos, entre em contacto com a nossa equipa de suporte.
Agradecemos a sua compreensão.

Atenciosamente,
<br>
Cotarco Tecnologias, Lda.
</x-mail::message>



